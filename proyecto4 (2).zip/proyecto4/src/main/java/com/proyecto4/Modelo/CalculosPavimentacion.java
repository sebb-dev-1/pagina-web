package com.proyecto4.Modelo;

public class CalculosPavimentacion {

    private double longitud; 
    private double ancho; 
    private double espesor;

    public CalculosPavimentacion(double longitud, double ancho, double espesor) {
        this.longitud = longitud;
        this.ancho = ancho;
        this.espesor = espesor;
    }

    
    public double calcularArea() {
        return longitud * ancho;
    }

    public double calcularVolumen() {
        return calcularArea() * espesor;
    }

    
    public double getLongitud() {
        return longitud;
    }

    public void setLongitud(double longitud) {
        this.longitud = longitud;
    }

    public double getAncho() {
        return ancho;
    }

    public void setAncho(double ancho) {
        this.ancho = ancho;
    }

    public double getEspesor() {
        return espesor;
    }

    public void setEspesor(double espesor) {
        this.espesor = espesor;
    }
}
