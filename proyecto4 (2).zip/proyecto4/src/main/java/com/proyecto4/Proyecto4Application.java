package com.proyecto4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Proyecto4Application {

	public static void main(String[] args) {
		SpringApplication.run(Proyecto4Application.class, args);
	}

}
