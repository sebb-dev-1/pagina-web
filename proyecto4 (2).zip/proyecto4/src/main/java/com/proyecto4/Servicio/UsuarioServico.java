package com.proyecto4.Servicio;

import com.proyecto4.DTO.UsuarioRegistroDTO;
import com.proyecto4.Modelo.Usuario;

public interface UsuarioServico  {
	
	public Usuario guardar(UsuarioRegistroDTO registrarDTO);

	
}
