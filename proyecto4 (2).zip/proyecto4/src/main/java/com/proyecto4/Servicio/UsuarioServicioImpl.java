package com.proyecto4.Servicio;

import java.util.Arrays;

import org.springframework.stereotype.Service;

import com.proyecto4.DTO.UsuarioRegistroDTO;
import com.proyecto4.Modelo.Rol;
import com.proyecto4.Modelo.Usuario;
import com.proyecto4.Repositorio.UsuarioRepositorio;

@Service
public class UsuarioServicioImpl implements UsuarioServico {

	private UsuarioRepositorio usuarioRepositorio;

	public UsuarioServicioImpl(UsuarioRepositorio usuarioRepositorio) {
		super();
		this.usuarioRepositorio = usuarioRepositorio;
	}

	@Override
	public Usuario guardar(UsuarioRegistroDTO registrarDTO) {
		Usuario usuario = new Usuario(registrarDTO.getNombre(), 
				registrarDTO.getApellido(), registrarDTO.getEmail(), registrarDTO.getPassword(), Arrays.asList(new Rol("ROLE_USER"))); 
		
		return usuarioRepositorio.save(usuario);
	}

}
