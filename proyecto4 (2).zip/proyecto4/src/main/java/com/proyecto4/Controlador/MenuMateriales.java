package com.proyecto4.Controlador;




public class MenuMateriales {

    protected String asfalto;
    protected String base_granular;
    protected String material_relleno;
    protected String material_sub_base;
    protected String aditivos;
    
    protected String Extendedora_asfalto;
    protected String compactadoras;
    protected String camiones_volquetas;
    protected String rodillos;
    protected String maquina_fresado;
    protected String equipo_señalizacion_vial;
    

    public MenuMateriales() {
        this.asfalto = "Asfalto: También conocido como alquitrán, es el material principal utilizado en la pavimentación de carreteras.";
        this.base_granular = "Base granular: Una capa de material granular que se coloca debajo del asfalto para proporcionar una base sólida y estable.";
        this.material_relleno = "Material de relleno: Se utiliza para nivelar y rellenar áreas antes de colocar la capa de base granular.";
        this.material_sub_base = "Material de sub-base: Un material más grueso que se coloca debajo de la base granular para proporcionar soporte adicional.";
        this.aditivos = "Aditivos: Pueden incluir productos químicos para mejorar las propiedades del asfalto, como la resistencia al agua o la durabilidad.";
        this.Extendedora_asfalto = "Extendedora de asfalto: Utilizada para colocar el asfalto de manera uniforme sobre la superficie de la carretera."; 
        this.compactadoras = "Compactadoras: Compactan el asfalto y las capas subyacentes para garantizar una superficie firme y duradera.";
        this.camiones_volquetas = "Camiones volquete: Transportan los materiales, como el asfalto y la base granular, al sitio de trabajo.";
        this.rodillos = "Rodillos: Se utilizan para compactar y nivelar el asfalto y las capas subyacentes.";
        this.maquina_fresado = "Máquina de fresado: Utilizada para retirar el asfalto antiguo y preparar la superficie antes de aplicar una nueva capa.";
        this.equipo_señalizacion_vial = "Equipo de señalización vial: Para marcar las líneas y señales de tráfico una vez que la pavimentación está completa.";
    }

    public String getAsfalto() {
        return asfalto;
    }

    public void setAsfalto(String asfalto) {
        this.asfalto = asfalto;
    }

    public String getBase_granular() {
        return base_granular;
    }

    public void setBase_granular(String base_granular) {
        this.base_granular = base_granular;
    }

    public String getMaterial_relleno() {
        return material_relleno;
    }

    public void setMaterial_relleno(String material_relleno) {
        this.material_relleno = material_relleno;
    }

    public String getMaterial_sub_base() {
        return material_sub_base;
    }

    public void setMaterial_sub_base(String material_sub_base) {
        this.material_sub_base = material_sub_base;
    }

    public String getAditivos() {
        return aditivos;
    }

    public void setAditivos(String aditivos) {
        this.aditivos = aditivos;
    }

    public String getExtendedora_asfalto() {
        return Extendedora_asfalto;
    }

    public void setExtendedora_asfalto(String Extendedora_asfalto) {
        this.Extendedora_asfalto = Extendedora_asfalto;
    }

    public String getCompactadoras() {
        return compactadoras;
    }

    public void setCompactadoras(String compactadoras) {
        this.compactadoras = compactadoras;
    }

    public String getCamiones_volquetas() {
        return camiones_volquetas;
    }

    public void setCamiones_volquetas(String camiones_volquetas) {
        this.camiones_volquetas = camiones_volquetas;
    }

    public String getRodillos() {
        return rodillos;
    }

    public void setRodillos(String rodillos) {
        this.rodillos = rodillos;
    }

    public String getMaquina_fresado() {
        return maquina_fresado;
    }

    public void setMaquina_fresado(String maquina_fresado) {
        this.maquina_fresado = maquina_fresado;
    }

    public String getEquipo_señalizacion_vial() {
        return equipo_señalizacion_vial;
    }

    public void setEquipo_señalizacion_vial(String equipo_señalizacion_vial) {
        this.equipo_señalizacion_vial = equipo_señalizacion_vial;
    }

    @Override
    public String toString() {
        return "asfalto: "+ asfalto +"\nbase_granular "+ base_granular +"\nmaterial_relleno: "+ material_relleno +"\nmaterial_sub_base: "+ material_sub_base +"\naditivos: "+ aditivos +"\nExtendedora_asfalto: "+ Extendedora_asfalto +"\ncompactadoras: "+ compactadoras +"\ncamiones_volquetas: "+ camiones_volquetas +"\nrodillos: "+ rodillos +"\nmaquina_fresado: "+ maquina_fresado +"\nequipo de señalizacion vial: "+ equipo_señalizacion_vial;
    }
    
    
    
    

}
