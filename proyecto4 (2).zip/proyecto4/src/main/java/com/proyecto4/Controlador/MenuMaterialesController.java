package com.proyecto4.Controlador;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MenuMaterialesController {

    @GetMapping("/api/menu-materiales")
    public MenuMateriales getMenuMateriales() {

        // instancia de MenuMateriale 
        
        return new MenuMateriales();
}
}
