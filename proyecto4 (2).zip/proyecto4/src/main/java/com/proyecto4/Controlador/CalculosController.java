package com.proyecto4.Controlador;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.proyecto4.Modelo.CalculosPavimentacion;

@RestController
@RequestMapping("/api/calculos")
public class CalculosController {

    @PostMapping("/pavimentacion")
    public ResultadoCalculo calcularPavimentacion(@RequestBody CalculosPavimentacion datos) {
        double area = datos.calcularArea();
        double volumen = datos.calcularVolumen();
        return new ResultadoCalculo(area, volumen);
    }
}


class ResultadoCalculo {
    private double area;
    private double volumen;

    public ResultadoCalculo(double area, double volumen) {
        this.area = area;
        this.volumen = volumen;
    }

    public double getArea() {
        return area;
    }

    public double getVolumen() {
        return volumen;
    }
}
