package com.proyecto4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Proyecto4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
