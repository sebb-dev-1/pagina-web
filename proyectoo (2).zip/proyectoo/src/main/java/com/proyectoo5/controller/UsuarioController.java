package com.proyectoo5.controller;

import java.util.List;
import java.util.Optional;

import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.proyectoo5.dto.LoginRequest;
import com.proyectoo5.model.UsuarioModel;
import com.proyectoo5.service.UsuarioService;



@RestController
@RequestMapping(path = "/api/v1/usuarios")
public class UsuarioController {

    @Autowired
    private UsuarioService usuarioService;

    @GetMapping
    public List<UsuarioModel> GetUsuarios() {
        return usuarioService.GetUsuarios();
    }

    @GetMapping("/byusername/{username}")
    public Optional<UsuarioModel> GetUsuarioByUsername(@PathVariable("username") String username) {
        return usuarioService.GetUsuarioByUsername(username);
    }

    @PostMapping
    public void save(@RequestBody UsuarioModel usuarioModel) {
        usuarioService.save(usuarioModel);
    }

    @GetMapping("/existe/{username}")
    public boolean UsuarioExists(@PathVariable("username") String username) {
        return usuarioService.UsuarioExists(username);
    }

    @PostMapping("/login")
    public ResponseEntity<ObjectId> iniciarSesion(@RequestBody LoginRequest request) {
        UsuarioModel usuario = usuarioService.iniciarSesion(request.getUsername(), request.getPassword());
        return ResponseEntity.ok(usuario.getId());
}

}
