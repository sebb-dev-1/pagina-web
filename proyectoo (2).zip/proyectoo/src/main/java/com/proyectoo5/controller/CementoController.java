package com.proyectoo5.controller;

import java.util.List;

import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.proyectoo5.model.CementoModel;
import com.proyectoo5.service.CementoService;

@RestController
@RequestMapping("/api/v1/calculo")
public class CementoController {


    @Autowired
    private CementoService cementoService;

    @PostMapping("/calcular")
    public ResponseEntity<CementoModel> calcularYGuardar(@RequestBody CementoModel calculoRequest) {
        int bolsas = cementoService.calcularBolsas(calculoRequest.getLongitud(), calculoRequest.getAncho(), calculoRequest.getEspesor());
        calculoRequest.setBolsasNecesarias(bolsas);

        CementoModel calculoGuardado = cementoService.guardarCalculo(calculoRequest);

        return ResponseEntity.ok(calculoGuardado);
    }

    @GetMapping("/usuario/{usuarioId}")
    public ResponseEntity<List<CementoModel>> obtenerHistorial(@PathVariable("usuarioId") String usuarioId) {
        List<CementoModel> historial = cementoService.obtenerCalculosPorUsuario(new ObjectId(usuarioId));
        return ResponseEntity.ok(historial);
    }
}
