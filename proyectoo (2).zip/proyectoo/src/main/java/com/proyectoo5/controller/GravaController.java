package com.proyectoo5.controller;

import java.util.List;

import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.proyectoo5.model.GravaModel;

import com.proyectoo5.service.GravaService;

@RestController
@RequestMapping("/api/v1/grava")
public class GravaController {

    @Autowired
    private GravaService gravaService;

    @PostMapping("/calcular")
    public ResponseEntity<GravaModel> calcularYGuardar(@RequestBody GravaModel calculoRequest) {
        int bolsas = gravaService.calcularBolsas(calculoRequest.getLongitud(), calculoRequest.getAncho(), calculoRequest.getEspesor());
        calculoRequest.setBolsasNecesarias(bolsas);

        GravaModel calculoGuardado = gravaService.guardarCalculo(calculoRequest);

        return ResponseEntity.ok(calculoGuardado);
    }

    @GetMapping("/usuario/{usuarioId}")
    public ResponseEntity<List<GravaModel>> obtenerHistorial(@PathVariable("usuarioId") String usuarioId) {
        List<GravaModel> historial = gravaService.obtenerCalculosPorUsuario(new ObjectId(usuarioId));
        return ResponseEntity.ok(historial);
    }

}
