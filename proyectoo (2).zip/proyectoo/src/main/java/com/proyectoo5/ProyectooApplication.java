package com.proyectoo5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectooApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectooApplication.class, args);
	}

}
