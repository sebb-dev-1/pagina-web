package com.proyectoo5.service;

import java.util.List;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.proyectoo5.model.ArenaModel;


import com.proyectoo5.repository.ArenaRepository;


@Service
public class ArenaService {

    @Autowired
    private ArenaRepository arenaRepository;

    public ArenaModel guardarCalculo(ArenaModel calculo) {
        return arenaRepository.save(calculo);
    }

    
    public List<ArenaModel> obtenerCalculosPorUsuario(ObjectId usuarioId) {
        return arenaRepository.findByUsuarioId(usuarioId);
    }

    
    public int calcularBolsas(double longitud, double ancho, double espesor) {
        double volumen = longitud * ancho * espesor;
        double rendimientoPorBolsa = 0.10;
        int bolsas = (int) Math.ceil(volumen / rendimientoPorBolsa);
        return bolsas;
    }

}
