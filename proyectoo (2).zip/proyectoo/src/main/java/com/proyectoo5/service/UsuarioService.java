package com.proyectoo5.service;



import java.util.List;
import java.util.Optional;

import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.proyectoo5.model.UsuarioModel;
import com.proyectoo5.repository.UsuarioRepository;


@Cacheable
@Service
public class UsuarioService {

    @Autowired
    private UsuarioRepository usuarioRepository;


    public List<UsuarioModel> GetUsuarios() {
        return usuarioRepository.findAll();
    }

    public Optional<UsuarioModel> GetUsuario(ObjectId id) {
        return usuarioRepository.findById(id);
    }

    public Optional<UsuarioModel> GetUsuarioByUsername(String username) {
        return usuarioRepository.findByUsername(username);
    }

    public boolean UsuarioExists(String username) {
        return usuarioRepository.existsByUsername(username);
    }

    public UsuarioModel save(UsuarioModel usuario) {
        return usuarioRepository.save(usuario);
    }

    public void delete(ObjectId id) {
        usuarioRepository.deleteById(id);
    }

        public UsuarioModel iniciarSesion(String username, String password) {
        UsuarioModel usuario = usuarioRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));

        if (!usuario.getPassword().equals(password)) {
            throw new RuntimeException("Contraseña incorrecta");
        }

        return usuario;
}

}
