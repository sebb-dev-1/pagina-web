package com.proyectoo5.model;


import java.util.Objects;

import org.bson.codecs.pojo.annotations.BsonProperty;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeName;

@JsonTypeName("usuario")
@Document("usuarios")
public class UsuarioModel {

    @BsonProperty("_id")
    private ObjectId id;

    @BsonProperty("username")
    private String username;

    @BsonProperty("password")
    private String password;


    public UsuarioModel() {

    }


    public UsuarioModel id (ObjectId id) {
        this.id = id;
        return this;
    }

    @JsonProperty("_id")
    public ObjectId getId() {
        return id;
    }


    public void setId(ObjectId id) {
        this.id = id;
    }



    

    public UsuarioModel username (String usename) {
        this.username = usename;
        return this;
    }


    @JsonProperty("username")
    public String getUsename() {
        return username;
    }


    public void setUsename(String usename) {
        this.username = usename;
    }



    

    public UsuarioModel password (String password) {
        this.password = password;
        return this;
    }


    @JsonProperty("password")
    public String getPassword() {
        return password;
    }


    public void setPassword(String password) {
        this.password = password;
    }



    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        UsuarioModel usuariosModel = (UsuarioModel) o;
        return Objects.equals(this.id, usuariosModel.id) &&
                Objects.equals(this.password, usuariosModel.password) &&
                Objects.equals(this.username, usuariosModel.username);
                
    }


    
    @Override
    public int hashCode() {
        return Objects.hash(id, password, username);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("class UsuarioModel {\n");
        sb.append("    id: ").append(toIndentedString(id)).append("\n");
        sb.append("    username: ").append(toIndentedString(username)).append("\n");
        sb.append("    password: ").append(toIndentedString(password)).append("\n");
        sb.append("}");

        return sb.toString();

    }
    
    private String toIndentedString(Object o) {
        if (o == null) {
            return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }
    
    
}
