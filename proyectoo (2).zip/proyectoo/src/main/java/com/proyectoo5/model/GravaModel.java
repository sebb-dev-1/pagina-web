package com.proyectoo5.model;

import org.bson.codecs.pojo.annotations.BsonProperty;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.mapping.Document;

@Document("calculos_grava")
public class GravaModel {

    @BsonProperty("_id")
    private ObjectId id;

    private double longitud;
    private double ancho;
    private double espesor;
    private int bolsasNecesarias;

    private ObjectId usuarioId;

    
    public GravaModel() {
    }


    public ObjectId getId() {
        return id;
    }


    public void setId(ObjectId id) {
        this.id = id;
    }


    public double getLongitud() {
        return longitud;
    }


    public void setLongitud(double longitud) {
        this.longitud = longitud;
    }


    public double getAncho() {
        return ancho;
    }


    public void setAncho(double ancho) {
        this.ancho = ancho;
    }


    public double getEspesor() {
        return espesor;
    }


    public void setEspesor(double espesor) {
        this.espesor = espesor;
    }


    public int getBolsasNecesarias() {
        return bolsasNecesarias;
    }


    public void setBolsasNecesarias(int bolsasNecesarias) {
        this.bolsasNecesarias = bolsasNecesarias;
    }


    public ObjectId getUsuarioId() {
        return usuarioId;
    }


    public void setUsuarioId(ObjectId usuarioId) {
        this.usuarioId = usuarioId;
    }


    
    

}
