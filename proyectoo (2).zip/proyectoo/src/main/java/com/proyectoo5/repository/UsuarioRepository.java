package com.proyectoo5.repository;


import java.util.Optional;

import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;

import com.proyectoo5.model.UsuarioModel;


public interface UsuarioRepository extends MongoRepository<UsuarioModel, ObjectId>{
    Optional<UsuarioModel> findByUsername(String username);
    boolean existsByUsername(String username);

}
