package com.proyectoo5.repository;

import java.util.List;

import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;

import com.proyectoo5.model.CementoModel;

public interface CementoRepository extends MongoRepository<CementoModel, ObjectId> {

    List<CementoModel> findByUsuarioId(ObjectId usuarioId);
}
