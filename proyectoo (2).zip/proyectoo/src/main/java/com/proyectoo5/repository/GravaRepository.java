package com.proyectoo5.repository;

import java.util.List;

import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;

import com.proyectoo5.model.GravaModel;

public interface GravaRepository  extends MongoRepository<GravaModel, ObjectId>{

    List<GravaModel> findByUsuarioId(ObjectId usuarioId);

}
