package com.proyectoo5.dto;

import java.io.Serializable;

import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
public class LoginRequest implements Serializable{

    private String username;
    private String password;

    
}
